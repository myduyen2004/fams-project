# FAMS - Danh Sách Users Mẫu

## Nội dung
- `users.csv`: File CSV chứa 100 users (80 sinh viên + 20 giảng viên)
- `avatars/`: Thư mục chứa ảnh avatar mẫu

## Cấu trúc file users.csv

| Column | Mô tả | Ví dụ |
|--------|-------|-------|
| code | Mã số (MSSV/MSGV) | SE000001, GV000001 |
| username | Tên đăng nhập | student1, lecturer1 |
| fullName | Họ và tên | Nguyễn Văn An |
| email | Email | an.nv1@fpt.edu.vn |
| dob | Ngày sinh (YYYY-MM-DD) | 2003-05-15 |
| phone | Số điện thoại | 0901234001 |
| role | Vai trò | STUDENT, LECTURER |
| status | Trạng thái | ACTIVE, INACTIVE |

## Thông tin users

### Sinh viên (80 người)
- Mã: SE000001 - SE000080
- Username: student1 - student80
- Password mặc định: **student123**
- Ngày sinh: 2003-2004

### Giảng viên (20 người)
- Mã: GV000001 - GV000020
- Username: lecturer1 - lecturer20
- Password mặc định: **lecturer123**
- Có học hàm/học vị: TS., ThS., PGS.TS.

## Avatars
- `avatar_male.png`: Avatar nam mẫu
- `avatar_female.png`: Avatar nữ mẫu

**Lưu ý**: Để import, bạn có thể sử dụng 2 avatar mẫu này hoặc tải thêm ảnh từ nguồn khác.

## Cách sử dụng
1. Import file `users.csv` vào hệ thống FAMS
2. Upload avatar cho từng user hoặc sử dụng avatar mặc định
